<div data-dismissible="bialty-reset-120" class="notice bialty-notice notice-success is-dismissible">
    <p class="bialty-p"><?php 
        echo __( 'Please note that the next update of <strong>"BIALTY - Bulk Image Alt Text"</strong> may reset some settings and will require to "re-apply" those settings again. Nothing is required at the moment.', 'bulk-image-alt-text-with-yoast' ); ?>
    </p>
</div>