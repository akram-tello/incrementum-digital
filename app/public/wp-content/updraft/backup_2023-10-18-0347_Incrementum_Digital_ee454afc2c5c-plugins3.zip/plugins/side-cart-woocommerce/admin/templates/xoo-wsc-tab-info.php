<p style="border: 1px solid #eee">
	<h3>How to translate?</h3>
	<h4>You can translate all your website texts using translation plugins such as "Loco translate"</h4>
</p>


<p style="border: 1px solid #eee">
	<h3>Basket Shortcode</h3>
	<h4>[xoo_wsc_cart]</h4>
</p>

<p style="border: 1px solid #eee">
	<h3>How to add to menu?</h3>
	<h4>General Tab -> Cart menu</h4>
</p>

<p style="border: 1px solid #eee">
	<h3>How to trigger side cart using your own icon?</h3>
	<h4>You can use your icon class and add it to settings -> advanced -> open side cart class or you can add plugin's class "xoo-wsc-cart-trigger" to your icon element. <br><br>For eg: Your HTML should look like this<br><xmp><div class="xoo-wsc-cart-trigger">Trigger Side Cart</div></xmp></h4>
</p>

<p style="border: 1px solid #eee">
	<h3>Having problem with footer button design?</h3>
	<h4>Go to style tab -> Side cart Footer & change button design option to "Custom", you can then set your own colors above</h4>
</p>

<p style="border: 1px solid #eee">
	<h3><a href="https://docs.xootix.com/side-cart-for-woocommerce" target="__blank">Documentation</a></h3>
</p>