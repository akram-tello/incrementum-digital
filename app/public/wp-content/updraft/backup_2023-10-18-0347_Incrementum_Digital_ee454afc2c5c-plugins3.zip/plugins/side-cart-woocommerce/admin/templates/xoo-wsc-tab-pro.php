<div class="xoo-wsc-premium">
	<div class="xoo-wscp-head">
		<span>Premium</span>
		<a href="https://xootix.com/plugins/side-cart-for-woocommerce">BUY NOW</a>
		<a href="https://demo.xootix.com/side-cart-for-woocommerce/">DEMO</a>
	</div>

	<h3>A complete replacement of your cart page</h3>

	<ul class="xoo-wscp-features">
		<li>Update quantity</li>
		<li>Show shipping, tax, discount, fee & other totals</li>
		<li>Shipping calculator</li>
		<li>Apply & display all coupons</li>
		<li>Increase sales by showing Cross-Sells / Up-Sells / Related products</li>
		<li>Show notifications on add/update/delete item</li>
		<li>Shipping bar( Remaining amount for free shipping )</li>
		<li>One Click Paypal and amazon pay checkout</li>
		<li>Select different basket icon or set your own.</li>
		<li>Header menu SHORTCODE (Use anywhere)</li>
		<li>Additional styling options</li>
	</ul>
</div>