<?php
include_once TAGEMBED_PLUGIN_DIR_PATH . "views/includes/headView.php";
include_once TAGEMBED_PLUGIN_DIR_PATH . "views/includes/headerView.php";
?>
<div class="__tagembed__support">
    <h3><a href="https://tagembed.com/support/" target="_blank">Knowledgebase</a> -</h3>
    <p>A collection of common scenarios and questions.</p>
    <p>The knowlegebase articles will help you troubleshoot issues that have previously been solved.</p>
</div>
<div class="__tagembed__support">
    <h3><a href="https://wordpress.org/support/plugin/tagembed-widget/" target="_blank">Tagembed WordPress.org Support</a> -</h3>
    <p>We actively monitor and answer all questions posted on WordPress.org</p>
</div>
<?php include_once TAGEMBED_PLUGIN_DIR_PATH . "views/includes/footerView.php"; ?>