<?php if ($__tagembed__chat_script): ?>
    <!--Start-- Tagembed Chat Script -->
    <script type="text/javascript">window.$crisp = [];
        window.CRISP_WEBSITE_ID = "c5d42bf5-f615-4318-930c-e61c35e565c1";
        (function () {
            d = document;
            s = d.createElement("script");
            s.src = "https://client.crisp.chat/l.js";
            s.async = 1;
            d.getElementsByTagName("head")[0].appendChild(s);
        })();
    </script>
    <!--End-- Tagembed Chat Script -->
<?php endif; ?>
</div>
</div>
<!--Start-- Manage Next And Back Button On All Pages  -->
<div id="__tagembed__next_and_back_link_main_section"></div>
<!--End-- Manage Next And Back Button On All Pages  -->
</div>
</div>
<!-- Other Default WordPress Css -->
<style> #footer-thankyou {font-style: normal !important;}</style>
<?php if ($__tagembed__active_menue_id != 4): ?>
    <style> body{min-height: auto!important;} </style>
<?php endif; ?>
<?php if ($__tagembed__active_menue_id == 6): ?>
    <script>
        /*--Start-- Manage Embed Accordion Section*/
        let __tagembed__accordionItem = document.getElementsByClassName('__tagembed__accordionItem');
        let __tagembed__accordionItemHeading = document.getElementsByClassName('__tagembed__accordionItemHeading');
        for (i = 0; i < __tagembed__accordionItemHeading.length; i++)
            __tagembed__accordionItemHeading[i].addEventListener('click', __tagembed__toggleAccodionSection, false);
        function __tagembed__toggleAccodionSection() {
            let __tagembed__accordionSectionClass = this.parentNode.className;
            for (i = 0; i < __tagembed__accordionItem.length; i++)
                __tagembed__accordionItem[i].className = '__tagembed__accordionItem __tagembed__close';
            if (__tagembed__accordionSectionClass == '__tagembed__accordionItem __tagembed__close')
                this.parentNode.className = '__tagembed__accordionItem __tagembed__open';
        }
        /*--End-- Manage Embed Accordion Section*/
    </script>
<?php endif; ?>
<script>
    /*--Start-- Manage And Generate Next And Back Link In Footer*/
    function __tagembed__manageNextAndBackButon() {
        let __tagembed__nextLink = null;
        let __tagembed__backLink = null;
        let __tagembed__nextAndBackLinkHtml = "";
        let __tagembed__next_and_back_link_main_section = document.querySelector("#__tagembed__next_and_back_link_main_section");
        __tagembed__next_and_back_link_main_section.innerHTML = "";
        let __tagembed__nextAndBackLinkSectionStyle = "block";
        let __tagembed__widgets_count = "<?php echo esc_html($__tagembed__widgets_count); ?>";
        let __tagembed__active_menue_id = "<?php echo esc_html($__tagembed__active_menue_id); ?>";
        if (__tagembed__widgets_count == 0) {
            __tagembed__nextAndBackLinkSectionStyle = "none";
        }
        switch (__tagembed__active_menue_id) {
            case "1" :
                __tagembed__nextLink = "2";
                __tagembed__backLink = null;
                break;
            case "2" :
                __tagembed__nextLink = "3";
                __tagembed__backLink = "1";
                __tagembed__nextAndBackLinkSectionStyle = "none"; /* Show In tagembed.feed.script.js */
                break;
            case "3" :
                __tagembed__nextLink = "4";
                __tagembed__backLink = "2";
                break;
            case "4" :
                __tagembed__nextLink = "5";
                __tagembed__backLink = "3";
                break;
            case "5" :
                __tagembed__nextLink = "6";
                __tagembed__backLink = "4";
                break;
            case "6" :
                __tagembed__nextLink = null;
                __tagembed__backLink = "5";
                break;
        }
        /* Manage Next And Back */
        if (__tagembed__nextLink != null || __tagembed__backLink != null) {
            __tagembed__nextAndBackLinkHtml = `${__tagembed__nextAndBackLinkHtml}<div class="__tagembed__foot_nextprevious" id="__tagembed__next_and_back_link_section" style="display:${__tagembed__nextAndBackLinkSectionStyle}">`;
            __tagembed__nextAndBackLinkHtml = `${__tagembed__nextAndBackLinkHtml}<div class="__tagembed__footnp_inn">`;
            if (__tagembed__backLink != null) {
                __tagembed__nextAndBackLinkHtml = `${__tagembed__nextAndBackLinkHtml}<button class="__tagembed__btn __tagembed__backbtn" onclick="__tagembed__menus(${__tagembed__backLink});"> <i class="fas fa-angle-left"></i> Back </button>`;
            }
            if (__tagembed__nextLink != null) {
                __tagembed__nextAndBackLinkHtml = `${__tagembed__nextAndBackLinkHtml}<button class="__tagembed__btn" onclick="__tagembed__menus(${__tagembed__nextLink});">Next <i class="fas fa-angle-right"></i> </button>`;
            }
            __tagembed__nextAndBackLinkHtml = `${__tagembed__nextAndBackLinkHtml}</div></div>`;
            __tagembed__next_and_back_link_main_section.innerHTML = __tagembed__nextAndBackLinkHtml;
        }
    }
    window.onload = __tagembed__manageNextAndBackButon();
    /*--End-- Manage And Generate Next And Back Link In Footer*/
</script>
