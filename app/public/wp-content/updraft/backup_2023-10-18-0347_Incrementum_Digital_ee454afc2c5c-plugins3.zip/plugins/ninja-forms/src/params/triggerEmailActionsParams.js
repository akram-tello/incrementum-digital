import { __ } from '@wordpress/i18n';

//TriggerEmailActions Params
export const triggerEmailActionsParams = {
	action: 'triggerEmailActions',
	title: __( 'Trigger Email Action Title', 'ninja-forms' ),
};
