import { __ } from '@wordpress/i18n';

export const bulkExportParams = {
	action: 'bulkExport',
	title: __( 'Bulk Export Title', 'ninja-forms' ),
};
