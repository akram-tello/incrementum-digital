<div data-pws-tab="Templates" data-pws-tab-name="Templates">
	<div class="sgpm-tabs-content">
		<div class="">
			<img class="sgpm-templates-img" title="Popup Maker Templates" alt="Popup Maker Templates" src="<?php echo SGPM_IMG_URL?>popup-maker-templates.jpg">
		</div>
		<div class="sgpm-more-templates-button-container">
			<a class="sgpm-font-size-20 sgpm-btn blue" target="_blank" href="<?php echo SGPM_SERVICE_URL.'solutions/website-popup-templates/'.SGPM_UTM_SOURCE_URL; ?>">
				More Templates
			</a>
		</div>
	</div>
</div>
