<div data-pws-tab="Help" data-pws-tab-name="Help">
	<div class="sgpm-tabs-content">
		<div class="sgpm-support-block-box-container">
			<iframe width="100%" height="350" src="https://www.youtube.com/embed/ekSNAR2lScY?list=UUhtxsnAzUmv02GZhiL66Nwg" frameborder="0" gesture="media" allowfullscreen></iframe>
			<iframe style="margin-top: 40px" width="100%" height="350" src="https://www.youtube.com/embed/WpRIoukJGEM?list=PLKztdznAVECGeU8NJAJakeOlsFHuoHJbZ" frameborder="0" gesture="media" allowfullscreen></iframe>
			<a href="<?php echo 'https://help.popupmaker.com/en/article/how-to-add-a-popup-in-wordpress-website-2s86ck/'?>" class="sgpm-support-block-box" target="_blank">
				<i class="dashicons dashicons-lightbulb sgpm-support-icons"></i>
				<p class="sgpm-support-block-box-title">Knowledgebase</p>
			</a>
		</div>
	</div>
</div>
